using System.ComponentModel;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter
{
    internal sealed class StoreProperties
    {
        [DefaultValue(9100)] public int CommandPort { get; set; } = 9100;
        [DefaultValue(443)] public int HttpsPort { get; set; } = 443;
        [DefaultValue(5000)] public int ConnectTimeoutMs { get; set; } = 5000;
        [DefaultValue(10000)] public int ReadTimeoutMs { get; set; } = 10000;
        [DefaultValue(true)] public bool ResetAfterChange { get; set; } = true;
        [DefaultValue(5000)] public int PostResetDelayMs { get; set; } = 5000;
        [DefaultValue(120000)] public int HttpsVerificationTimeoutMs { get; set; } = 120000;
        [DefaultValue(5000)] public int HttpsVerificationPollMs { get; set; } = 5000;
        [DefaultValue("E:")] public string Drive { get; set; } = "E:";
    }
}
