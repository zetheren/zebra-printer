using System;
using System.Diagnostics;
using System.Threading;
using Keyfactor.Extensions.Orchestrator.ZebraPrinter.Certificate;
using Keyfactor.Logging;
using Keyfactor.Orchestrators.Common.Enums;
using Keyfactor.Orchestrators.Extensions;
using Keyfactor.Orchestrators.Extensions.Interfaces;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter.Jobs
{
    public sealed class Management : JobBase, IManagementJobExtension
    {
        private static readonly string[] HttpsFiles = { "HTTPS_CERT.NRD", "HTTPS_KEY.NRD", "HTTPS_CA.NRD" };
        public Management(IPAMSecretResolver resolver) : base(resolver) { Logger = LogHandler.GetClassLogger<Management>(); }
        public string ExtensionName => "ZebraZD621";

        public JobResult ProcessJob(ManagementJobConfiguration config)
        {
            if (config == null) return Failure(0, "Management configuration is null.");
            try
            {
                var props = Properties(config.CertificateStoreDetails.Properties);
                var client = CreateClient(config.CertificateStoreDetails.ClientMachine, config.CertificateStoreDetails.StorePath, props);
                switch (config.OperationType)
                {
                    case CertStoreOperationType.Add:
                        return Add(config, client, props);
                    case CertStoreOperationType.Remove:
                        return Remove(config, client, props);
                    default:
                        return Failure(config.JobHistoryId, $"Unsupported management operation: {config.OperationType}.");
                }
            }
            catch (Exception ex) { Logger.LogError(ex, "Zebra management failed."); return Failure(config.JobHistoryId, ex); }
        }

        private JobResult Add(ManagementJobConfiguration config, Client.IZebraClient client, StoreProperties props)
        {
            var exists = client.FileExists("HTTPS_CERT.NRD") || client.FileExists("HTTPS_KEY.NRD");
            if (exists && !config.Overwrite) return Failure(config.JobHistoryId, "The printer already has an HTTPS certificate. Select Overwrite to replace it.");
            var bundle = PfxConverter.Convert(config.JobCertificate.Contents, config.JobCertificate.PrivateKeyPassword);
            foreach (var file in HttpsFiles) if (client.FileExists(file)) client.DeleteFile(file);
            client.UploadNrd("HTTPS_KEY.NRD", bundle.PrivateKey);
            client.UploadNrd("HTTPS_CERT.NRD", bundle.Certificate);
            var certificateUploaded = client.FileExists("HTTPS_CERT.NRD");
            var privateKeyUploaded = client.FileExists("HTTPS_KEY.NRD");
            if (!certificateUploaded || !privateKeyUploaded)
                throw new InvalidOperationException(
                    $"Zebra upload verification failed. HTTPS_CERT.NRD present: {certificateUploaded}; HTTPS_KEY.NRD present: {privateKeyUploaded}.");
            if (!props.ResetAfterChange)
                return Success(config.JobHistoryId,
                    $"Installed Zebra HTTPS certificate {bundle.LeafThumbprint} as separate HTTPS_CERT.NRD and HTTPS_KEY.NRD files. " +
                    "TLS activation was not verified because ResetAfterChange is false.");

            client.Reset();
            VerifyActiveHttpsCertificate(client, bundle.LeafThumbprint, props);
            return Success(config.JobHistoryId,
                $"Installed and activated Zebra HTTPS certificate {bundle.LeafThumbprint}. The certificate presented on port {props.HttpsPort} matches the Keyfactor-delivered certificate.");
        }

        private JobResult Remove(ManagementJobConfiguration config, Client.IZebraClient client, StoreProperties props)
        {
            foreach (var file in HttpsFiles) if (client.FileExists(file)) client.DeleteFile(file);
            if (props.ResetAfterChange) client.Reset();
            return Success(config.JobHistoryId, $"Removed Zebra HTTPS certificate files. Printer reset requested: {props.ResetAfterChange}.");
        }

        internal static void VerifyActiveHttpsCertificate(Client.IZebraClient client, string expectedThumbprint,
            StoreProperties props)
        {
            if (props.PostResetDelayMs < 0 || props.HttpsVerificationTimeoutMs <= 0 || props.HttpsVerificationPollMs <= 0)
                throw new ArgumentOutOfRangeException(nameof(props), "HTTPS verification timing values must be positive; PostResetDelayMs may be zero.");

            if (props.PostResetDelayMs > 0) Thread.Sleep(props.PostResetDelayMs);
            var timer = Stopwatch.StartNew();
            Exception lastError = null;
            string lastThumbprint = null;

            while (timer.ElapsedMilliseconds < props.HttpsVerificationTimeoutMs)
            {
                try
                {
                    using (var presented = client.GetPresentedHttpsCertificate())
                    {
                        lastThumbprint = presented.Thumbprint;
                        if (ThumbprintsEqual(expectedThumbprint, lastThumbprint)) return;
                    }
                }
                catch (Exception ex)
                {
                    lastError = ex;
                }

                var remaining = props.HttpsVerificationTimeoutMs - timer.ElapsedMilliseconds;
                if (remaining > 0) Thread.Sleep((int)Math.Min(props.HttpsVerificationPollMs, remaining));
            }

            var detail = lastThumbprint == null
                ? $"The HTTPS endpoint never returned a certificate. Last error: {lastError?.Message ?? "none"}"
                : $"The HTTPS endpoint presented thumbprint {lastThumbprint}, expected {NormalizeThumbprint(expectedThumbprint)}.";
            throw new TimeoutException(
                $"The Zebra printer did not activate the Keyfactor-delivered HTTPS certificate within {props.HttpsVerificationTimeoutMs} ms. {detail}");
        }

        internal static bool ThumbprintsEqual(string left, string right) =>
            string.Equals(NormalizeThumbprint(left), NormalizeThumbprint(right), StringComparison.OrdinalIgnoreCase);

        private static string NormalizeThumbprint(string value) =>
            (value ?? string.Empty).Replace(" ", string.Empty).Replace(":", string.Empty).Trim();
    }
}
