using System;
using System.IO;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter.Client
{
    internal sealed class ZebraClient : IZebraClient
    {
        private readonly string host;
        private readonly StoreProperties properties;

        public ZebraClient(string host, StoreProperties properties)
        {
            this.host = string.IsNullOrWhiteSpace(host) ? throw new ArgumentException("Printer host is required.") : host;
            this.properties = properties ?? throw new ArgumentNullException(nameof(properties));
        }

        public string GetVariable(string name) => SendForResponse($"! U1 getvar \"{Escape(name)}\"\r\n");
        public string Do(string name, string value) => SendForResponse($"! U1 do \"{Escape(name)}\" \"{Escape(value)}\"\r\n");

        public bool FileExists(string fileName)
        {
            var directory = Do("file.dir", properties.Drive);
            return directory.IndexOf(fileName, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        public void UploadNrd(string fileName, byte[] content)
        {
            if (content == null || content.Length == 0) throw new ArgumentException("Upload content is empty.", nameof(content));
            var baseName = Path.GetFileNameWithoutExtension(fileName).ToUpperInvariant();
            var header = Encoding.ASCII.GetBytes($"~DY{properties.Drive}{baseName}.NRD,B,NRD,{content.Length},,");

            using (var tcp = Connect(properties.CommandPort))
            using (var stream = tcp.GetStream())
            {
                stream.WriteTimeout = properties.ReadTimeoutMs;
                stream.Write(header, 0, header.Length);
                stream.Write(content, 0, content.Length);
                stream.Flush();
            }
        }

        public void DeleteFile(string fileName) => Do("file.delete", properties.Drive + fileName);
        public void Reset() => SendNoResponse("! U1 do \"device.reset\" \"\"\r\n");

        public X509Certificate2 GetPresentedHttpsCertificate()
        {
            X509Certificate2 result = null;
            using (var tcp = Connect(properties.HttpsPort))
            using (var ssl = new SslStream(tcp.GetStream(), false, (sender, certificate, chain, errors) =>
            {
                if (certificate != null) result = new X509Certificate2(certificate.Export(X509ContentType.Cert));
                return true;
            }))
            {
                ssl.ReadTimeout = properties.ReadTimeoutMs;
                ssl.WriteTimeout = properties.ReadTimeoutMs;
                ssl.AuthenticateAsClient(host);
            }
            return result ?? throw new InvalidOperationException("The printer did not present an HTTPS certificate.");
        }

        private string SendForResponse(string command)
        {
            using (var tcp = Connect(properties.CommandPort))
            using (var stream = tcp.GetStream())
            {
                stream.ReadTimeout = properties.ReadTimeoutMs;
                stream.WriteTimeout = properties.ReadTimeoutMs;
                var request = Encoding.UTF8.GetBytes(command);
                stream.Write(request, 0, request.Length);
                stream.Flush();

                using (var output = new MemoryStream())
                {
                    var buffer = new byte[4096];
                    try
                    {
                        int count;
                        while ((count = stream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            output.Write(buffer, 0, count);
                            if (!stream.DataAvailable) break;
                        }
                    }
                    catch (IOException) when (output.Length > 0) { }
                    return Encoding.UTF8.GetString(output.ToArray()).Trim().Trim('"');
                }
            }
        }

        private void SendNoResponse(string command)
        {
            using (var tcp = Connect(properties.CommandPort))
            using (var stream = tcp.GetStream())
            {
                stream.WriteTimeout = properties.ReadTimeoutMs;
                var request = Encoding.UTF8.GetBytes(command);
                stream.Write(request, 0, request.Length);
                stream.Flush();
            }
        }

        private TcpClient Connect(int port)
        {
            var tcp = new TcpClient();
            var task = tcp.ConnectAsync(host, port);
            if (!task.Wait(properties.ConnectTimeoutMs))
            {
                tcp.Dispose();
                throw new TimeoutException($"Timed out connecting to Zebra printer {host}:{port}.");
            }
            task.GetAwaiter().GetResult();
            return tcp;
        }

        private static string Escape(string value) => (value ?? string.Empty).Replace("\\", "\\\\").Replace("\"", "\\\"");
    }
}
