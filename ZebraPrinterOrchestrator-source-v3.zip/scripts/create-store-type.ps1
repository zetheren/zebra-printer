param(
    [Parameter(Mandatory)] [string] $KeyfactorHostname,
    [Parameter(Mandatory)] [string] $AccessToken,
    [string] $ApiPath = "KeyfactorAPI"
)

$Headers = @{
    Authorization = "Bearer $AccessToken"
    "Content-Type" = "application/json"
    "x-keyfactor-requested-with" = "APIClient"
}

$Body = @{
    Name = "Zebra ZD621 HTTPS"
    ShortName = "ZebraZD621"
    Capability = "ZebraZD621"
    ServerRequired = $false
    BlueprintAllowed = $false
    CustomAliasAllowed = "Forbidden"
    PowerShell = $false
    PrivateKeyAllowed = "Required"
    StorePathType = "Freeform"
    StorePathValue = "zebra://printer-host:9100/HTTPS"
    SupportedOperations = @{ Add = $true; Create = $false; Discovery = $true; Enrollment = $false; Remove = $true }
    PasswordOptions = @{ Style = "Default"; EntrySupported = $false; StoreRequired = $false }
    Properties = @(
        @{ Name = "CommandPort"; DisplayName = "ZPL/SGD Command Port"; Type = "String"; DefaultValue = "9100"; Required = $true; IsPAMEligible = $false; Description = "TCP raw port used for Zebra SGD and ~DY commands." },
        @{ Name = "HttpsPort"; DisplayName = "HTTPS Port"; Type = "String"; DefaultValue = "443"; Required = $true; IsPAMEligible = $false; Description = "TLS port from which inventory reads the active certificate." },
        @{ Name = "ConnectTimeoutMs"; DisplayName = "Connect Timeout (ms)"; Type = "String"; DefaultValue = "5000"; Required = $true; IsPAMEligible = $false },
        @{ Name = "ReadTimeoutMs"; DisplayName = "Read Timeout (ms)"; Type = "String"; DefaultValue = "10000"; Required = $true; IsPAMEligible = $false },
        @{ Name = "ResetAfterChange"; DisplayName = "Reset Printer After Change"; Type = "MultipleChoice"; DefaultValue = "true"; Options = "true,false"; Required = $true; IsPAMEligible = $false },
        @{ Name = "PostResetDelayMs"; DisplayName = "Post-Reset Delay (ms)"; Type = "String"; DefaultValue = "5000"; Required = $true; IsPAMEligible = $false; Description = "Delay before checking the HTTPS certificate after requesting a printer reset." },
        @{ Name = "HttpsVerificationTimeoutMs"; DisplayName = "HTTPS Verification Timeout (ms)"; Type = "String"; DefaultValue = "120000"; Required = $true; IsPAMEligible = $false; Description = "Maximum time to wait for the printer to present the newly installed certificate." },
        @{ Name = "HttpsVerificationPollMs"; DisplayName = "HTTPS Verification Poll Interval (ms)"; Type = "String"; DefaultValue = "5000"; Required = $true; IsPAMEligible = $false },
        @{ Name = "Drive"; DisplayName = "Printer Storage Drive"; Type = "String"; DefaultValue = "E:"; Required = $true; IsPAMEligible = $false }
    )
    EntryParameters = @()
} | ConvertTo-Json -Depth 10

Invoke-RestMethod -Uri "https://$KeyfactorHostname/$ApiPath/CertificateStoreTypes" -Method Post -Headers $Headers -Body $Body
