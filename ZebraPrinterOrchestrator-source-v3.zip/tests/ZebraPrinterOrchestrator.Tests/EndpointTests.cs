using System.Linq;
using Keyfactor.Extensions.Orchestrator.ZebraPrinter.Client;
using Keyfactor.Extensions.Orchestrator.ZebraPrinter.Jobs;
using Xunit;

namespace ZebraPrinterOrchestrator.Tests
{
    public class EndpointTests
    {
        [Theory]
        [InlineData("printer01", null, "printer01")]
        [InlineData("ignored", "zebra://10.1.2.3:9100/HTTPS", "10.1.2.3")]
        [InlineData("ignored", "printer01:9100/HTTPS", "printer01")]
        public void ResolveHost_ParsesStorePath(string machine, string path, string expected) =>
            Assert.Equal(expected, ZebraEndpoint.ResolveHost(machine, path));

        [Fact]
        public void ExpandCidr_ExcludesNetworkAndBroadcast()
        {
            var hosts = Discovery.ExpandCidr("192.168.10.0/30").ToArray();
            Assert.Equal(new[] { "192.168.10.1", "192.168.10.2" }, hosts);
        }

        [Theory]
        [InlineData("AABBCC", "aa:bb:cc", true)]
        [InlineData("AA BB CC", "aabbcc", true)]
        [InlineData("AABBCC", "AABB00", false)]
        public void ThumbprintsEqual_NormalizesCommonFormats(string left, string right, bool expected) =>
            Assert.Equal(expected, Management.ThumbprintsEqual(left, right));
    }
}
