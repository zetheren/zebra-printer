using System;
using Keyfactor.Extensions.Orchestrator.ZebraPrinter.Certificate;
using Keyfactor.Logging;
using Keyfactor.Orchestrators.Common.Enums;
using Keyfactor.Orchestrators.Extensions;
using Keyfactor.Orchestrators.Extensions.Interfaces;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter.Jobs
{
    public sealed class Management : JobBase, IManagementJobExtension
    {
        private static readonly string[] HttpsFiles = { "HTTPS_CERT.NRD", "HTTPS_KEY.NRD", "HTTPS_CA.NRD" };
        public Management(IPAMSecretResolver resolver) : base(resolver) { Logger = LogHandler.GetClassLogger<Management>(); }
        public string ExtensionName => "ZebraZD621";

        public JobResult ProcessJob(ManagementJobConfiguration config)
        {
            if (config == null) return Failure(0, "Management configuration is null.");
            try
            {
                var props = Properties(config.CertificateStoreDetails.Properties);
                var client = CreateClient(config.CertificateStoreDetails.ClientMachine, config.CertificateStoreDetails.StorePath, props);
                switch (config.OperationType)
                {
                    case CertStoreOperationType.Add:
                        return Add(config, client, props);
                    case CertStoreOperationType.Remove:
                        return Remove(config, client, props);
                    default:
                        return Failure(config.JobHistoryId, $"Unsupported management operation: {config.OperationType}.");
                }
            }
            catch (Exception ex) { Logger.LogError(ex, "Zebra management failed."); return Failure(config.JobHistoryId, ex); }
        }

        private JobResult Add(ManagementJobConfiguration config, Client.IZebraClient client, StoreProperties props)
        {
            var exists = client.FileExists("HTTPS_CERT.NRD") || client.FileExists("HTTPS_KEY.NRD");
            if (exists && !config.Overwrite) return Failure(config.JobHistoryId, "The printer already has an HTTPS certificate. Select Overwrite to replace it.");
            var bundle = PfxConverter.Convert(config.JobCertificate.Contents, config.JobCertificate.PrivateKeyPassword);
            foreach (var file in HttpsFiles) if (client.FileExists(file)) client.DeleteFile(file);
            client.UploadNrd("HTTPS_KEY.NRD", bundle.PrivateKey);
            client.UploadNrd("HTTPS_CERT.NRD", bundle.Certificate);
            var certificateUploaded = client.FileExists("HTTPS_CERT.NRD");
            var privateKeyUploaded = client.FileExists("HTTPS_KEY.NRD");
            if (!certificateUploaded || !privateKeyUploaded)
                throw new InvalidOperationException(
                    $"Zebra upload verification failed. HTTPS_CERT.NRD present: {certificateUploaded}; HTTPS_KEY.NRD present: {privateKeyUploaded}.");
            if (props.ResetAfterChange) client.Reset();
            return Success(config.JobHistoryId,
                $"Installed Zebra HTTPS certificate {bundle.LeafThumbprint} as separate HTTPS_CERT.NRD and HTTPS_KEY.NRD files. Printer reset requested: {props.ResetAfterChange}.");
        }

        private JobResult Remove(ManagementJobConfiguration config, Client.IZebraClient client, StoreProperties props)
        {
            foreach (var file in HttpsFiles) if (client.FileExists(file)) client.DeleteFile(file);
            if (props.ResetAfterChange) client.Reset();
            return Success(config.JobHistoryId, $"Removed Zebra HTTPS certificate files. Printer reset requested: {props.ResetAfterChange}.");
        }
    }
}
