# Changelog

## 0.2.0 - 2026-08-18

- Changed HTTPS deployment to create and upload separate `HTTPS_CERT.NRD` and `HTTPS_KEY.NRD` files.
- Added post-upload verification requiring both Zebra objects before the printer reset is requested.

## 0.1.0 - 2026-08-18

- Initial Zebra ZD621 HTTPS certificate-store implementation.
- Added inventory, management add/replace, management remove, and discovery jobs.
- Added raw Zebra SGD/ZPL transport, PKCS#12-to-PEM conversion, CIDR discovery, store-type creation script, and unit tests.
