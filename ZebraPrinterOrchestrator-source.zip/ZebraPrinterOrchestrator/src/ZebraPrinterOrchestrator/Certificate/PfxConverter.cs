using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Pkcs;
using Org.BouncyCastle.X509;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter.Certificate
{
    internal sealed class ZebraPemBundle
    {
        public byte[] Combined { get; set; }
        public string LeafThumbprint { get; set; }
    }

    internal static class PfxConverter
    {
        internal static ZebraPemBundle Convert(string base64Pfx, string password)
        {
            var bytes = System.Convert.FromBase64String(base64Pfx ?? throw new ArgumentNullException(nameof(base64Pfx)));
            var store = new Pkcs12StoreBuilder().Build();
            using (var input = new MemoryStream(bytes)) store.Load(input, (password ?? string.Empty).ToCharArray());
            var alias = store.Aliases.Cast<string>().FirstOrDefault(store.IsKeyEntry);
            if (alias == null) throw new InvalidOperationException("The delivered PKCS#12 does not contain a private key.");
            var key = store.GetKey(alias)?.Key ?? throw new InvalidOperationException("Unable to extract the private key.");
            var chain = store.GetCertificateChain(alias);
            if (chain == null || chain.Length == 0) throw new InvalidOperationException("The delivered PKCS#12 does not contain a certificate.");

            string pem;
            using (var writer = new StringWriter())
            {
                var pemWriter = new PemWriter(writer);
                pemWriter.WriteObject(key);
                foreach (var entry in chain) pemWriter.WriteObject(entry.Certificate);
                writer.Flush();
                pem = writer.ToString().Replace("\r\n", "\n");
            }

            var leaf = new System.Security.Cryptography.X509Certificates.X509Certificate2(chain[0].Certificate.GetEncoded());
            return new ZebraPemBundle { Combined = Encoding.ASCII.GetBytes(pem), LeafThumbprint = leaf.Thumbprint };
        }
    }
}
