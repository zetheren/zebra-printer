using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("ZebraPrinterOrchestrator.Tests")]
