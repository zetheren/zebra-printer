using System;
using Keyfactor.Logging;
using Keyfactor.Orchestrators.Common.Enums;
using Keyfactor.Orchestrators.Extensions;
using Keyfactor.Orchestrators.Extensions.Interfaces;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Keyfactor.Extensions.Orchestrator.ZebraPrinter.Client;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter.Jobs
{
    public abstract class JobBase
    {
        protected ILogger Logger;
        protected readonly IPAMSecretResolver Resolver;
        protected JobBase(IPAMSecretResolver resolver) { Resolver = resolver ?? throw new ArgumentNullException(nameof(resolver)); }

        protected static StoreProperties Properties(string json)
        {
            if (string.IsNullOrWhiteSpace(json)) return new StoreProperties();
            return JsonConvert.DeserializeObject<StoreProperties>(json,
                new JsonSerializerSettings { DefaultValueHandling = DefaultValueHandling.Populate }) ?? new StoreProperties();
        }

        protected static JobResult Success(long id, string message = "") => new JobResult
        { Result = OrchestratorJobStatusJobResult.Success, JobHistoryId = id, FailureMessage = message ?? "" };
        protected static JobResult Failure(long id, Exception ex) => Failure(id, ex.Message);
        protected static JobResult Failure(long id, string message) => new JobResult
        { Result = OrchestratorJobStatusJobResult.Failure, JobHistoryId = id, FailureMessage = message ?? "Unknown error" };

        protected static IZebraClient CreateClient(string clientMachine, string storePath, StoreProperties properties) =>
            new ZebraClient(ZebraEndpoint.ResolveHost(clientMachine, storePath), properties);
    }
}
