using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Keyfactor.Extensions.Orchestrator.ZebraPrinter.Client;
using Keyfactor.Logging;
using Keyfactor.Orchestrators.Extensions;
using Keyfactor.Orchestrators.Extensions.Interfaces;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter.Jobs
{
    public sealed class Discovery : JobBase, IDiscoveryJobExtension
    {
        private static readonly string[] TargetKeys = { "dirs", "Dirs", "directories", "Directories", "DirsToSearch", "Targets" };
        public Discovery(IPAMSecretResolver resolver) : base(resolver) { Logger = LogHandler.GetClassLogger<Discovery>(); }
        public string ExtensionName => "ZebraZD621";

        public JobResult ProcessJob(DiscoveryJobConfiguration config, SubmitDiscoveryUpdate submitDiscoveryUpdate)
        {
            if (config == null) return Failure(0, "Discovery configuration is null.");
            try
            {
                var targets = GetTargets(config).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                var discovered = new ConcurrentBag<string>();
                Parallel.ForEach(targets, new ParallelOptions { MaxDegreeOfParallelism = 32 }, host =>
                {
                    try
                    {
                        var client = new ZebraClient(host, new StoreProperties());
                        var model = client.GetVariable("device.product_name");
                        if (model.IndexOf("ZD621", StringComparison.OrdinalIgnoreCase) >= 0)
                            discovered.Add($"zebra://{host}:9100/HTTPS");
                    }
                    catch (Exception ex) { Logger.LogDebug(ex, "Discovery skipped {Host}.", host); }
                });
                var ordered = discovered.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
                submitDiscoveryUpdate(ordered);
                return Success(config.JobHistoryId, $"Discovered {discovered.Count} Zebra ZD621 printer(s) from {targets.Count} target(s).");
            }
            catch (Exception ex) { Logger.LogError(ex, "Zebra discovery failed."); return Failure(config.JobHistoryId, ex); }
        }

        private static IEnumerable<string> GetTargets(DiscoveryJobConfiguration config)
        {
            string raw = null;
            if (config.JobProperties != null)
                foreach (var key in TargetKeys)
                    if (config.JobProperties.TryGetValue(key, out var value) && !string.IsNullOrWhiteSpace(value?.ToString())) { raw = value.ToString(); break; }
            if (string.IsNullOrWhiteSpace(raw)) raw = config.ClientMachine;
            foreach (var token in (raw ?? string.Empty).Split(new[] { ',', ';', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var item = token.Trim();
                if (item.Contains("/")) foreach (var host in ExpandCidr(item)) yield return host;
                else yield return ZebraEndpoint.ResolveHost(item, null);
            }
        }

        internal static IEnumerable<string> ExpandCidr(string cidr)
        {
            var parts = cidr.Split('/');
            if (parts.Length != 2 || !IPAddress.TryParse(parts[0], out var ip) || !int.TryParse(parts[1], out var prefix))
                throw new FormatException($"Invalid discovery CIDR: {cidr}.");
            var bytes = ip.GetAddressBytes();
            if (bytes.Length != 4 || prefix < 16 || prefix > 32) throw new ArgumentException("Discovery supports IPv4 CIDRs from /16 through /32.");
            var address = ((uint)bytes[0] << 24) | ((uint)bytes[1] << 16) | ((uint)bytes[2] << 8) | bytes[3];
            var mask = prefix == 0 ? 0U : uint.MaxValue << (32 - prefix);
            var network = address & mask;
            var count = 1U << (32 - prefix);
            if (count > 4096) throw new ArgumentException("A discovery range may contain at most 4096 addresses.");
            var start = count > 2 ? 1U : 0U;
            var end = count > 2 ? count - 1 : count;
            for (var i = start; i < end; i++)
            {
                var value = network + i;
                yield return $"{value >> 24}.{(value >> 16) & 255}.{(value >> 8) & 255}.{value & 255}";
            }
        }
    }
}
