using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using Keyfactor.Extensions.Orchestrator.ZebraPrinter.Client;
using Keyfactor.Logging;
using Keyfactor.Orchestrators.Common.Enums;
using Keyfactor.Orchestrators.Extensions;
using Keyfactor.Orchestrators.Extensions.Interfaces;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter.Jobs
{
    public sealed class Inventory : JobBase, IInventoryJobExtension
    {
        public Inventory(IPAMSecretResolver resolver) : base(resolver) { Logger = LogHandler.GetClassLogger<Inventory>(); }
        public string ExtensionName => "ZebraZD621";

        public JobResult ProcessJob(InventoryJobConfiguration config, SubmitInventoryUpdate submitInventoryUpdate)
        {
            if (config == null) return Failure(0, "Inventory configuration is null.");
            try
            {
                var props = Properties(config.CertificateStoreDetails.Properties);
                var client = CreateClient(config.CertificateStoreDetails.ClientMachine, config.CertificateStoreDetails.StorePath, props);
                var items = new List<CurrentInventoryItem>();
                if (client.FileExists("HTTPS_CERT.NRD"))
                {
                    using (var cert = client.GetPresentedHttpsCertificate())
                    {
                        items.Add(new CurrentInventoryItem
                        {
                            Alias = "HTTPS",
                            Certificates = new[] { ToPem(cert) },
                            PrivateKeyEntry = true,
                            UseChainLevel = false,
                            ItemStatus = OrchestratorInventoryItemStatus.Unknown,
                            Parameters = new Dictionary<string, object>
                            {
                                ["Service"] = "HTTPS",
                                ["Thumbprint"] = cert.Thumbprint
                            }
                        });
                    }
                }
                submitInventoryUpdate(items);
                return Success(config.JobHistoryId, $"Inventoried {items.Count} Zebra HTTPS certificate(s).");
            }
            catch (Exception ex) { Logger.LogError(ex, "Zebra inventory failed."); return Failure(config.JobHistoryId, ex); }
        }

        private static string ToPem(X509Certificate2 cert)
        {
            var body = Convert.ToBase64String(cert.RawData, Base64FormattingOptions.InsertLineBreaks);
            return $"-----BEGIN CERTIFICATE-----\n{body.Replace("\r\n", "\n")}\n-----END CERTIFICATE-----";
        }
    }
}
