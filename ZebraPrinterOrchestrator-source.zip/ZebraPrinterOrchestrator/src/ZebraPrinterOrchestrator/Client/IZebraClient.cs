using System.Security.Cryptography.X509Certificates;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter.Client
{
    internal interface IZebraClient
    {
        string GetVariable(string name);
        string Do(string name, string value);
        bool FileExists(string fileName);
        void UploadNrd(string fileName, byte[] content);
        void DeleteFile(string fileName);
        void Reset();
        X509Certificate2 GetPresentedHttpsCertificate();
    }
}
