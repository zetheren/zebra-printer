using System;

namespace Keyfactor.Extensions.Orchestrator.ZebraPrinter.Client
{
    internal static class ZebraEndpoint
    {
        internal static string ResolveHost(string clientMachine, string storePath)
        {
            var value = string.IsNullOrWhiteSpace(storePath) ? clientMachine : storePath;
            if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("Client Machine or Store Path must identify the printer.");
            value = value.Trim();
            if (value.StartsWith("zebra://", StringComparison.OrdinalIgnoreCase)) value = value.Substring(8);
            var slash = value.IndexOf('/');
            if (slash >= 0) value = value.Substring(0, slash);
            if (value.StartsWith("[", StringComparison.Ordinal) && value.Contains("]")) return value.Substring(1, value.IndexOf(']') - 1);
            var colon = value.LastIndexOf(':');
            if (colon > 0 && value.IndexOf(':') == colon) value = value.Substring(0, colon);
            return value;
        }
    }
}
